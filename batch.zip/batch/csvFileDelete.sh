#!/bin/bash

#######################################
##
## CSVファイル削除処理
##
#######################################

java -jar /data/batch/lib/BatchCSVFileDelete.jar /data/csv
