PATH=$PATH:/usr/libexec
sudo mysqld --user=root