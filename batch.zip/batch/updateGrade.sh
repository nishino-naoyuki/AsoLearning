#!/bin/bash


#######################################
##
## 学年更新処理
##
#######################################

java -jar /data/batch/lib/BatchUpdateGrade.jar